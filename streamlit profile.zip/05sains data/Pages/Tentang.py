import streamlit as st
from PIL import Image

st.title("Muhammad Fahrezi")

image = Image.open("Team logo/Rezi_tampan.jpg")

new_size = (350, 350)

resized_image = image.resize(new_size)

st.image(resized_image)

## info about the team
st.write("Muhammad Fahrezi lahir pada 18 Juni 2001, di kota pangkal pinang, Provinsi Kepulauan Bangka Belitung")
st.write("Rezi banyak menghabiskan masa kecilnya di desa jebus kecamatan jebus, Kab. Bangka Barat. Di sana ia menempuh pendidikan sekolah dasar dari SD, SMP, SMA dan kemudian menempuh pendidikan perkuliahan di Universitas Muhammadiyah Bangka Belitung.")

st.subheader("Di bawah adalah beberapa media sosial yang bisa dikunjungi")

## for Player
st.header("Muhammad Fahrezi")
st.info('Ilmu Komputer')
lead=Image.open('Team logo/Rezi_tampan.jpg')
size=(400, 400)
lead_image=lead.resize(size)
st.image(lead_image)

st.subheader("Connect dengan Muhammad Fahrezi: ")

# Button to send an email 
if st.button("Contact Me Via Email"):
    st.markdown('<a href="mailto:www.costa188@gmail.com">Send Email</a>', unsafe_allow_html=True)

# Button to visit Linkedin profile
if st.button("visit My Linkedin Profile"):
    st.markdown('<a href="https://www.linkedin.com/in/muhammad-fahrezi-348562229?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app">Linkedin</a>', unsafe_allow_html=True)

# Button to visit medium
if st.button("Read my blogs"):
    st.markdown('<a href="">Medium</a>', unsafe_allow_html=True)

# Button to github
if st.button("Check out my github Repositories"):
    st.markdown('<a href="https://github.com/Heat88">Github</a>', unsafe_allow_html=True)