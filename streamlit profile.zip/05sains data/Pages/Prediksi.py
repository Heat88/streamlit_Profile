# load libraries
import streamlit as st
import pandas as pd
import numpy as np
import joblib
from streamlit_lottie import st_lottie
from datetime import datetime
from sklearn.preprocessing import OrdinalEncoder

# load the encoders from files
LE = joblib.load('Encoders/label_encoder.pkl')
BE = joblib.load('Encoders/binary_encoder.pkl')
OE = joblib.load('Encoders/ordinal_encoder.pkl')

# load the model
model = joblib.load('Model/model.pkl')

# define app section
header = st.container()
prediction = st.container()

# define the Lottie animation URL
lottie_animation_url = "https://lottie.host/fc3a2d24-7acd-439d-875c-65d208bcfc85/fkuGk5jtnO.json"

# define header 
with header:
    header.title(
        "Aplikasi Prediksi Penjualan Dengan Regresi Linier Di Seluruh Toko Favorita")
    
    # display the Lottie animation using st_lottie
    st_lottie(lottie_animation_url, height=200)

    header.write("Di halaman ini, anda dapat memprediksi penjualan")


# create lists
inputs = ["date", "holidays", "locale", "transferred", "onpromotion",]
categorical = ["holidays", "locale", "transferred",]

# Set up prediction container
with st.expander("Buat Prediksi", expanded=True):

    # Define streamlit inputs
    date = st.date_input(label="Masukkan tanggal")
    holidays = st.selectbox(label="Pilih kategori hari libur", options=[
                            'Holidays', 'Not Holiday', 'Workday', 'Addtional', 'Event', 'Transfer', 'Bridge'])
    locale = st.radio(label="Pliih tipe hari libur", options=[
                    "National", "Regional", "Local", "Not Holiday"], horizontal=True)
    transferred = st.radio(label="Pliih apakah hari libur dipindahkan atau tidak", options=[
                    "True", "False"], horizontal=True)
    onpromotion = st.number_input(
        label="Silahkan masukkan jumlah total item yang diharapkan ada pada promosi")
    
# create a button
predicted = st.button("Prediksi")

# Flag variable to control visibility of the predictions messages
show_predictions_message = False
    # Upon predicting
if predicted:
    show_predictions_message = True
    input_dict = {
        "date": [date],
        "holiday": [holidays],
        "locale": [locale],
        "transferred": [transferred],
        "onpromotion": [onpromotion]
    }

    input_df = pd.DataFrame.from_dict(input_dict)

    input_df["transferred"] = LE.transform(input_df["transferred"])
    input_df = BE.transform(input_df)

    hier = ["National", "Regional", "Local", "Not Holidays"]

    OE = OrdinalEncoder(categories= [hier])

    input_df[["locale"]] = OE.fit_transform(input_df[["locale"]])

    input_df["date"] = pd.to_datetime(input_df["date"])

    #  extract date features and add to input_df
    input_df['year'] = input_df['date'].dt.year
    input_df['month'] = input_df['date'].dt.month
    input_df['day'] = input_df['date'].dt.day
    input_df['day_of_week'] = input_df['date'].dt.dayofweek
    input_df['day_of_year'] = input_df['date'].dt.dayofyear
    input_df['week_of_year'] = input_df['date'].dt.isocalendar().week
    input_df['quarter'] = input_df['date'].dt.quarter
    input_df['is_weekend'] = (
        input_df['date'].dt.dayofweek // 5 == 1).astype(int)
    input_df['day_of_month'] = input_df['date'].dt.day


    input_df.drop(columns=['date'], inplace=True)


    model_output = model.predict(input_df)

    rounded_output = np.round(model_output, 2)

    input_dict["Total Sales($)"] = rounded_output

    formatted_output = f"<b>${rounded_output[0]}</b>"


    st.write(
        f"Total prediksi penjualan anda akan menjadi {formatted_output}", unsafe_allow_html=True)
    

if show_predictions_message:
    st.write("datagrame yang berisi masukan dan perkiraan penjualan anda ditunjukkan di bawah ini:")
    st.dataframe(input_dict)

    